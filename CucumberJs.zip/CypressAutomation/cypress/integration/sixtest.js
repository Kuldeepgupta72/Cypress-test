describe('Test Suit', function() {
    it('Test Case alert windows', function()  {
        cy.visit('http://testautomationpractice.blogspot.com/')
        cy.get("button[onclick='myFunction()']").click()
        cy.on('window:confirm', (str)=>{
            expect(str).to.equal('Press a button!')
        })
        cy.get("button[onclick='myFunction()']").click()
        cy.on("window:confirm", (str) => {
            return false;
          });
    })
  })