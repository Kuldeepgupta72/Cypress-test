describe('Test Suit', function() {
    it('Test Case1', function()  {
        cy.visit('https://demo.nopcommerce.com/')
        cy.title().should('eq','nopCommerce demo store')
        cy.contains('nopCommerce').title().should('eq','nopCommerce demo store')
    })
  })