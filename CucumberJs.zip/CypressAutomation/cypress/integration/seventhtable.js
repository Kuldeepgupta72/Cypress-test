describe('Test Suit', function() {
    it('Test Case alert windows', function()  {
        cy.visit('http://testautomationpractice.blogspot.com/')
        cy.get('#HTML1 > h2').scrollIntoView().should('be.visible')
        cy.get("table[name='BookTable']").contains('td','Learn Java').should('be.visible')
        //Particular row and column operation
        cy.get("#HTML1 > div.widget-content > table > tbody > tr:nth-child(3) > td:nth-child(3)").contains('Java').should('be.visible')
        //particular column operation
        cy.get('#HTML1 > div.widget-content > table > tbody > tr:nth-child(3)').each(($e,index,$list) =>{
            const text=$e.text()
            if(text.includes('Selenium')){
                cy.get('#HTML1 > div.widget-content > table > tbody > tr:nth-child(2)').eq(index).then(function(bname){
                   const name=bname.text()
                    expect(name).to.equal('Mukesh')
                })
            }
        })
    })

})