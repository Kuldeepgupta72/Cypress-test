///<reference types='cypress' />

const { includes } = require("lodash")
describe('Test Suit', function() {
it('Mercury Demo input & Radio buttons', function()  {
        cy.visit('http://demo.guru99.com/test/newtours/')
        cy.url().should('include','/test/newtours/')
        cy.title().should('eq','Welcome: Mercury Tours')
        cy.get('input[name=userName]').should('be.visible').should('be.enabled').type("Mercury")
        cy.get('input[name=password]').should('be.visible').should('be.enabled').type("Mercury")
        cy.get("input[name=submit]").should('be.visible').contains('Submit').click()   
    })
})
   