///<reference types='cypress' />

describe('Test Suit', function() {

    before( function(){
cy.log("Before setup")
    })
    
    after( function(){
        cy.log("After setup")
    })

    
    beforeEach( function(){
        cy.log("Before each setup")
    })
    
    afterEach( function(){
        cy.log("after each setup")
    })
    it('Test Case alert windows', function()  {
      
    })

    it('Test Case alert windows', function()  {
      
    })

    it('Test Case alert windows', function()  {
      
    })
})