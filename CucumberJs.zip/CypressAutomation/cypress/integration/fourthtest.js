///<reference types='cypress' />

const { includes } = require("lodash")

describe('Test Suit', function() {
 it('Demo automation testing with checked box and dropdown', function()  {
    cy.visit('http://demo.automationtesting.in/Register.html')
    cy.url().should('include','/Register.html')
    cy.title().should('eq','Register')
    cy.get("input[value='Male']").should('be.visible').should('not.be.checked').click()
    cy.get("input[value='FeMale']").should('be.visible').should('not.be.checked') 
    cy.get("#checkbox1").should('be.visible').check().should('be.checked').should('have.value','Cricket')
    cy.get("#checkbox1").should('be.visible').uncheck().should('not.be.checked').should('have.value','Cricket')
    
    cy.get("Input[type=checkbox]").should('be.visible').first().check().should('be.checked').should('have.value','Cricket')
    cy.get("Input[type=checkbox]").should('be.visible').check(['Movies','Hockey']).should('be.checked').should('have.value','Movies')
}),
it(' dropdown type1', function()  {
    //Handle dropdown
    cy.get('#Skills').select('Android').should('have.value','Android')
}),
it('Dropdown type2', function()  {
    //Handle dropdown
    cy.get('#msdd').click()
    cy.get('.ui-corner-all').contains('Japanese').click()
    cy.get('.ui-corner-all').contains('English').click()
    cy.get('.ui-corner-all').contains('Hindi').click()
}),
it('Dropdown type3', function()  {
    //Handle dropdown
    cy.get('[role=combobox]').click('{force : true}')
    cy.get('.select2-search__field').type('india')
    cy.get('.select2-search__field').type('{enter}')      
    
})

})