package com.ttn.webautomation.utillib;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtils {
	public static String getFormattedCurrentDateTime() {
		Timestamp timestamp = new Timestamp(System.currentTimeMillis());
		return timestamp.toString();
	}

	public static String getFormattedTimeDiffInMin(String dateStart, String dateStop) {
		String data = "";
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date d1 = format.parse(dateStart);
			Date d2 = format.parse(dateStop);
			long diff = d2.getTime() - d1.getTime();
			long diffSeconds = diff / 1000;
			long diffMinutes = diff / (60 * 1000);
			long diffHours = diff / (60 * 60 * 1000);
			data = "Total Time taken " + diffHours + ":" + diffMinutes + ":" + diffSeconds;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return data;
	}
	
	public static String getTimeDiffInSec(String dateStart, String dateStop) {
		String data = "";
		try {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Date d1 = format.parse(dateStart);
			Date d2 = format.parse(dateStop);
			long diff = d2.getTime() - d1.getTime();
			long diffSeconds = diff / 1000;
			data = ""+diffSeconds;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return data;
	}

}
