Logger logger;
	BillingSummaryPage summaryPage;

	/**
	 * Private constructor for singleton.
	 */
	public BillingSummaryPageHelper() {
		this.logger = LoggerFactory.getLogger(BillingSummaryPageHelper.class);
		this.summaryPage = new BillingSummaryPage();
	}
	
	
	Global Valirable
	
	
	blic static String outputLogFolder = "output";
	public static String outputlogFileName = "outputlog";
	
		public static String getCurrentDirctoryPath() throws IOException {
		return directory.getCanonicalPath() + File.separator;
	}

	public static String getResourcesPath() throws IOException {
		return directory.getCanonicalPath() + File.separator + "resources"
				+ File.separator;
	}

	public static String getExtentConfigPath() throws IOException {
		return directory.getCanonicalPath() + GlobalVariables.SEP + System.getProperty("user.dir") + GlobalVariables.SEP
				+ "target/" + GlobalVariables.SEP + "screenshot/" + GlobalVariables.SEP;
	}

	public static final SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyy hh:mm:ss");
