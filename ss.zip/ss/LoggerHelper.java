package com.ttn.webautomation.properties;

import java.io.File;
import java.io.IOException;

import org.slf4j.LoggerFactory;

import com.ttn.webautomation.utillib.FileUtils;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.joran.JoranConfigurator;
import ch.qos.logback.core.joran.spi.JoranException;

public class LoggerHelper {

	public static void updateLoggerProperties() {
		try {
			FileUtils.createDirectory(new File(GlobalVariables.getCurrentDirctoryPath()), GlobalVariables.outputLogFolder);
			LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();
			JoranConfigurator joranConfigurator = new JoranConfigurator();
			joranConfigurator.setContext(context);
			context.reset();
			context.putProperty("LOGGING_PATH", GlobalVariables.outputLogFolder);
			context.putProperty("LOGGING_FILE_NAME", outputlogFileName());
			joranConfigurator.doConfigure(GlobalVariables.getResourcesPath()+"logger/logback.xml");
		} catch (JoranException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String outputlogFileName() {
		StringBuilder fileName = new StringBuilder();
		fileName.append("output-logs");
		fileName.append(GlobalVariables.HYPHEN);
		fileName.append("Regression_suite");
		fileName.append(GlobalVariables.HYPHEN);
		return fileName.toString();
	}
	
}
